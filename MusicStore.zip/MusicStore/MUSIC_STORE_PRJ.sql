CREATE DATABASE MUSIC_STORE;
USE MUSIC_STORE;
-- DROP DATABASE MUSIC_STORE;

-- 1. Genre and MediaType 
CREATE TABLE Genre ( 
genre_id INT PRIMARY KEY, 
name VARCHAR(120) 
); 
CREATE TABLE MediaType ( 
media_type_id INT PRIMARY KEY, 
name VARCHAR(120) 
); 
SELECT COUNT(*) FROM MEDIATYPE;
-- 2. Employee 
 
CREATE TABLE Employee ( 
 employee_id INT PRIMARY KEY, 
 last_name VARCHAR(120), 
 first_name VARCHAR(120), 
 title VARCHAR(120), 
 reports_to INT, 
  levels VARCHAR(255), 
 birthdate DATE, 
 hire_date DATE, 
 address VARCHAR(255), 
 city VARCHAR(100), 
 state VARCHAR(100), 
 country VARCHAR(100), 
 postal_code VARCHAR(20), 
 phone VARCHAR(50), 
 fax VARCHAR(50), 
 email VARCHAR(100) 
); 
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/MusicStore/employee.csv'
INTO TABLE employee
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(employee_id, last_name, first_name, title, @reports_to, levels, birthdate, hire_date,
address, city, state, country, postal_code, phone, fax, email)
SET reports_to = NULLIF(@reports_to, '');

 -- 3. Customer 
CREATE TABLE Customer ( 
 customer_id INT PRIMARY KEY, 
 first_name VARCHAR(120), 
 last_name VARCHAR(120), 
 company VARCHAR(120), 
 address VARCHAR(255), 
 city VARCHAR(100), 
 state VARCHAR(100), 
 country VARCHAR(100), 
 postal_code VARCHAR(20), 
 phone VARCHAR(50), 
 fax VARCHAR(50), 
 email VARCHAR(100), 
 support_rep_id INT, 
 FOREIGN KEY (support_rep_id) REFERENCES Employee(employee_id) 
); 
 -- 4. Artist 
CREATE TABLE Artist ( 
 artist_id INT PRIMARY KEY, 
 name VARCHAR(120) 
); 
 -- 5. Album 
CREATE TABLE Album ( 
 album_id INT PRIMARY KEY, 
 title VARCHAR(160), 
 artist_id INT, 
 FOREIGN KEY (artist_id) REFERENCES Artist(artist_id) 
); 
 -- 6. Track 
CREATE TABLE Track ( 
 
 track_id INT PRIMARY KEY, 
 name VARCHAR(200), 
 album_id INT, 
 media_type_id INT, 
 genre_id INT, 
 composer VARCHAR(220), 
 milliseconds INT, 
 bytes INT, 
 unit_price DECIMAL(10,2), 
 FOREIGN KEY (album_id) REFERENCES Album(album_id), 
 FOREIGN KEY (media_type_id) REFERENCES MediaType(media_type_id), 
 FOREIGN KEY (genre_id) REFERENCES Genre(genre_id) 
); 
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/MusicStore/track.csv'
INTO TABLE track
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(track_id, name, album_id, media_type_id, genre_id, composer, milliseconds, bytes, unit_price);

 -- 7. Invoice 
CREATE TABLE Invoice ( 
 invoice_id INT PRIMARY KEY, 
 customer_id INT, 
 invoice_date DATE, 
 billing_address VARCHAR(255), 
 billing_city VARCHAR(100), 
 billing_state VARCHAR(100), 
 billing_country VARCHAR(100), 
 billing_postal_code VARCHAR(20), 
 total DECIMAL(10,2), 
 FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) 
); 
 -- 8. InvoiceLine 
CREATE TABLE InvoiceLine ( 
 invoice_line_id INT PRIMARY KEY, 
 invoice_id INT, 
 track_id INT, 
 unit_price DECIMAL(10,2), 
 quantity INT, 
 FOREIGN KEY (invoice_id) REFERENCES Invoice(invoice_id), 
 FOREIGN KEY (track_id) REFERENCES Track(track_id) 
); 


 -- 9. Playlist 
CREATE TABLE Playlist ( 
  playlist_id INT PRIMARY KEY, 
 name VARCHAR(255) 
); 
 -- 10. PlaylistTrack 
CREATE TABLE PlaylistTrack ( 
 playlist_id INT, 
 track_id INT, 
 PRIMARY KEY (playlist_id, track_id), 
 FOREIGN KEY (playlist_id) REFERENCES Playlist(playlist_id), 
 FOREIGN KEY (track_id) REFERENCES Track(track_id) 
); 


SELECT COUNT(*) AS Genre_Count FROM genre;
SELECT COUNT(*) AS MediaType_Count FROM mediatype;
SELECT COUNT(*) AS Artist_Count FROM artist;
SELECT COUNT(*) AS Album_Count FROM album;
SELECT COUNT(*) AS Employee_Count FROM employee;
SELECT COUNT(*) AS Customer_Count FROM customer;
SELECT COUNT(*) AS Track_Count FROM track;
SELECT COUNT(*) AS Invoice_Count FROM invoice;
SELECT COUNT(*) AS InvoiceLine_Count FROM invoice_line;
SELECT COUNT(*) AS Playlist_Count FROM playlist;
SELECT COUNT(*) AS PlaylistTrack_Count FROM playlisttrack;

SELECT * FROM music_store.album;
SELECT * FROM music_store.artist;
SELECT * FROM music_store.customer;
SELECT * FROM music_store.employee;--
SELECT * FROM music_store.genre;
SELECT * FROM music_store.invoice;
SELECT * FROM music_store.invoiceline; 
SELECT * FROM music_store.mediatype;
SELECT * FROM music_store.playlist;
SELECT * FROM music_store.playlisttrack; 
SELECT * FROM music_store.track; --

-- 1. Who is the senior most employee based on job title?  
SELECT * FROM EMPLOYEE ORDER BY LEVELS DESC LIMIT 1;

-- 2. Which countries have the most Invoices? 
SELECT BILLING_COUNTRY,COUNT(INVOICE_ID) AS TOTAL_INVOICES FROM INVOICE 
GROUP BY BILLING_COUNTRY ORDER BY TOTAL_INVOICES DESC LIMIT 1; 

-- 3. What are the top 3 values of total invoice? 
SELECT INVOICE_ID,TOTAL FROM INVOICE ORDER BY TOTAL DESC LIMIT 3;

-- 4. Which city has the best customers? - We would like to throw a promotional Music Festival in 
-- the city we made the most money. Write a query that returns one city that has the highest sum of 
-- invoice totals. Return both the city name & sum of all invoice totals 
SELECT CUSTOMER.CITY,SUM(INVOICE.TOTAL) AS INVOICE_TOTALS FROM CUSTOMER
JOIN INVOICE ON CUSTOMER.CUSTOMER_ID=INVOICE.CUSTOMER_ID 
GROUP BY CUSTOMER.CITY ORDER BY INVOICE_TOTALS DESC LIMIT 1;

-- 5. Who is the best customer? - The customer who has spent the most money will be declared 
-- the best customer. Write a query that returns the person who has spent the most money 
SELECT CUSTOMER.CUSTOMER_ID,CUSTOMER.FIRST_NAME,CUSTOMER.LAST_NAME,SUM(INVOICE.TOTAL) AS HIGH_SPENT FROM CUSTOMER
JOIN INVOICE ON CUSTOMER.CUSTOMER_ID=INVOICE.CUSTOMER_ID
GROUP BY CUSTOMER.CUSTOMER_ID,CUSTOMER.FIRST_NAME,CUSTOMER.LAST_NAME ORDER BY HIGH_SPENT DESC LIMIT 1;

-- 6. Write a query to return the email, first name, last name, & Genre of all Rock Music listeners.
-- Return your list ordered alphabetically by email starting with A 
SELECT DISTINCT CUSTOMER.EMAIL,CUSTOMER.FIRST_NAME,CUSTOMER.LAST_NAME, GENRE.NAME AS GENRE_NAME FROM CUSTOMER
JOIN INVOICE ON CUSTOMER.CUSTOMER_ID=INVOICE.CUSTOMER_ID
JOIN INVOICELINE ON INVOICE.INVOICE_ID=INVOICELINE.INVOICE_ID
JOIN TRACK ON INVOICELINE.TRACK_ID=TRACK.TRACK_ID
JOIN GENRE ON TRACK.GENRE_ID=GENRE.GENRE_ID
WHERE GENRE.NAME="ROCK" ORDER BY CUSTOMER.EMAIL;

-- 7. Lets invite the artists who have written the most rock music in our dataset. Write a query that 
-- returns the Artist name and total track count of the top 10 rock bands  
SELECT ARTIST.NAME,GENRE.NAME AS GENRE_NAME,COUNT(TRACK_ID) AS TRACK_ID_COUNT FROM ARTIST
JOIN ALBUM ON ARTIST.ARTIST_ID=ALBUM.ARTIST_ID
JOIN TRACK ON ALBUM.ALBUM_ID=TRACK.ALBUM_ID
JOIN GENRE ON TRACK.GENRE_ID=GENRE.GENRE_ID
WHERE GENRE.NAME='ROCK' GROUP BY ARTIST.NAME,GENRE_NAME ORDER BY TRACK_ID_COUNT DESC LIMIT 10;

-- 8. Return all the track names that have a song length longer than the average song length.- 
-- Return the Name and Milliseconds for each track. Order by the song length, with the longest 
-- songs listed first 
SELECT MAX(TRACK.MILLISECONDS) FROM TRACK;
SELECT AVG(TRACK.MILLISECONDS) FROM TRACK;
SELECT TRACK.NAME,TRACK.MILLISECONDS FROM TRACK 
WHERE TRACK.MILLISECONDS > (SELECT AVG(TRACK.MILLISECONDS) FROM TRACK) 
ORDER BY TRACK.MILLISECONDS DESC LIMIT 1;

-- 9. Find how much amount is spent by each customer on artists? Write a query to return 
-- customer name, artist name and total spent (CUS-INV-INVLINE-TRACK-ALB-ART)
SELECT DISTINCT CUSTOMER.FIRST_NAME,CUSTOMER.LAST_NAME,ARTIST.NAME, SUM(INVOICELINE.UNIT_PRICE*INVOICELINE.QUANTITY) AS TOTAL_SPENT FROM CUSTOMER
JOIN INVOICE ON CUSTOMER.CUSTOMER_ID=INVOICE.CUSTOMER_ID
JOIN INVOICELINE ON INVOICE.INVOICE_ID=INVOICELINE.INVOICE_ID
JOIN TRACK ON INVOICELINE.TRACK_ID=TRACK.TRACK_ID
JOIN ALBUM ON TRACK.ALBUM_ID=ALBUM.ALBUM_ID
JOIN ARTIST ON ALBUM.ARTIST_ID=ARTIST.ARTIST_ID
GROUP BY CUSTOMER.FIRST_NAME,CUSTOMER.LAST_NAME,ARTIST.NAME ORDER BY TOTAL_SPENT;

 
-- 10. We want to find out the most popular music Genre for each country. We determine the most 
-- popular genre as the genre with the highest amount of purchases. Write a query that returns 
-- each country along with the top Genre. For countries where the maximum number of purchases 
-- is shared, return all Genres 
WITH GENRE_PURCHASES AS(
SELECT INVOICE.BILLING_COUNTRY, GENRE.NAME AS GENRE_NAME,COUNT(INVOICELINE.INVOICE_LINE_ID) AS PURCHASES
FROM INVOICE
JOIN INVOICELINE ON INVOICE.INVOICE_ID = INVOICELINE.INVOICE_ID
JOIN TRACK ON INVOICELINE.TRACK_ID = TRACK.TRACK_ID
JOIN GENRE ON TRACK.GENRE_ID = GENRE.GENRE_ID
GROUP BY INVOICE.BILLING_COUNTRY,GENRE.GENRE_ID,GENRE.NAME),

GENRE_RANK AS(
SELECT BILLING_COUNTRY,GENRE_NAME,PURCHASES, DENSE_RANK() 
OVER(PARTITION BY BILLING_COUNTRY ORDER BY PURCHASES DESC) AS RNK
FROM GENRE_PURCHASES)
SELECT BILLING_COUNTRY, GENRE_NAME, PURCHASES FROM GENRE_RANK
WHERE RNK = 1 ORDER BY BILLING_COUNTRY;

-- 11. Write a query that determines the customer that has spent the most on music for each 
-- country. Write a query that returns the country along with the top customer and how much they 
-- spent. For countries where the top amount spent is shared, provide all customers who spent this 
-- amount
WITH CUSTOMER_SPENDING AS(
SELECT INVOICE.BILLING_COUNTRY,CUSTOMER.CUSTOMER_ID,CUSTOMER.FIRST_NAME,CUSTOMER.LAST_NAME,SUM(INVOICE.TOTAL) AS TOTAL_SPENT
FROM CUSTOMER JOIN INVOICE ON CUSTOMER.CUSTOMER_ID = INVOICE.CUSTOMER_ID
GROUP BY INVOICE.BILLING_COUNTRY,CUSTOMER.CUSTOMER_ID,CUSTOMER.FIRST_NAME,CUSTOMER.LAST_NAME),

COUNTRY_RANK AS(
SELECT BILLING_COUNTRY,CUSTOMER_ID,FIRST_NAME,LAST_NAME,TOTAL_SPENT,DENSE_RANK() 
OVER(PARTITION BY BILLING_COUNTRY ORDER BY TOTAL_SPENT DESC) AS RANKING
FROM CUSTOMER_SPENDING)

SELECT BILLING_COUNTRY,CUSTOMER_ID,FIRST_NAME,LAST_NAME,TOTAL_SPENT
FROM COUNTRY_RANK
WHERE RANKING = 1
ORDER BY BILLING_COUNTRY DESC;